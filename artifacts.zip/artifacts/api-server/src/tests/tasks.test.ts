/**
 * Integration tests for /api/tasks endpoints
 *
 * Uses Node.js built-in test runner (node:test) with supertest for HTTP
 * assertions and tsx for TypeScript support.
 *
 * Run: pnpm --filter @workspace/api-server test
 */
import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import request from "supertest";
import app from "../app.js";

// ─── GET /api/tasks ──────────────────────────────────────────────────────────

describe("GET /api/tasks", () => {
  it("returns HTTP 200 with an array", async () => {
    const res = await request(app).get("/api/tasks");

    assert.equal(res.status, 200, `Expected 200 but got ${res.status}`);
    assert.ok(Array.isArray(res.body), `Expected body to be an array, got ${typeof res.body}`);
  });

  it("returns tasks sorted by sortOrder ascending", async () => {
    const res = await request(app).get("/api/tasks");

    assert.equal(res.status, 200);
    const tasks: { sortOrder: number }[] = res.body;

    if (tasks.length >= 2) {
      for (let i = 1; i < tasks.length; i++) {
        assert.ok(
          tasks[i - 1]!.sortOrder <= tasks[i]!.sortOrder,
          `Tasks not sorted: index ${i - 1} sortOrder ${tasks[i - 1]!.sortOrder} > index ${i} sortOrder ${tasks[i]!.sortOrder}`,
        );
      }
    }
  });

  it("accepts a status=active filter and returns only incomplete tasks", async () => {
    const res = await request(app).get("/api/tasks?status=active");

    assert.equal(res.status, 200);
    assert.ok(Array.isArray(res.body));
    const tasks: { completed: boolean }[] = res.body;
    assert.ok(
      tasks.every((t) => t.completed === false),
      "Some tasks in active filter have completed=true",
    );
  });

  it("accepts a status=completed filter and returns only completed tasks", async () => {
    const res = await request(app).get("/api/tasks?status=completed");

    assert.equal(res.status, 200);
    assert.ok(Array.isArray(res.body));
    const tasks: { completed: boolean }[] = res.body;
    assert.ok(
      tasks.every((t) => t.completed === true),
      "Some tasks in completed filter have completed=false",
    );
  });
});

// ─── GET /api/tasks/stats ────────────────────────────────────────────────────

describe("GET /api/tasks/stats", () => {
  it("returns HTTP 200 with numeric total, active, completed, overdue fields", async () => {
    const res = await request(app).get("/api/tasks/stats");

    assert.equal(res.status, 200);
    const { total, active, completed, overdue } = res.body as Record<string, unknown>;
    assert.ok(typeof total === "number",    `total should be number, got ${typeof total}`);
    assert.ok(typeof active === "number",   `active should be number, got ${typeof active}`);
    assert.ok(typeof completed === "number",`completed should be number, got ${typeof completed}`);
    assert.ok(typeof overdue === "number",  `overdue should be number, got ${typeof overdue}`);
  });

  it("total equals active + completed", async () => {
    const res = await request(app).get("/api/tasks/stats");

    assert.equal(res.status, 200);
    const { total, active, completed } = res.body as { total: number; active: number; completed: number };
    assert.equal(
      total,
      active + completed,
      `total (${total}) should equal active (${active}) + completed (${completed})`,
    );
  });
});

// ─── POST /api/tasks ─────────────────────────────────────────────────────────

describe("POST /api/tasks", () => {
  let createdTaskId: number;

  it("returns 400 when title is missing", async () => {
    const res = await request(app)
      .post("/api/tasks")
      .send({ description: "No title provided" })
      .set("Content-Type", "application/json");

    assert.equal(res.status, 400, `Expected 400 but got ${res.status}`);
    assert.ok(res.body.error, "Expected an error field in the response body");
  });

  it("returns 400 when title is an empty string", async () => {
    const res = await request(app)
      .post("/api/tasks")
      .send({ title: "" })
      .set("Content-Type", "application/json");

    assert.equal(res.status, 400);
  });

  it("creates a task and returns 201 with the new task object", async () => {
    const res = await request(app)
      .post("/api/tasks")
      .send({ title: "Test task from integration suite", priority: "medium" })
      .set("Content-Type", "application/json");

    assert.equal(res.status, 201, `Expected 201 but got ${res.status}: ${JSON.stringify(res.body)}`);

    const task = res.body as Record<string, unknown>;
    assert.ok(typeof task["id"] === "number", "task.id should be a number");
    assert.equal(task["title"], "Test task from integration suite");
    assert.equal(task["completed"], false);
    assert.equal(task["priority"], "medium");

    createdTaskId = task["id"] as number;
  });

  // ─── PATCH /api/tasks/:id ──────────────────────────────────────────────────

  it("updates the task title via PATCH /:id", async () => {
    if (!createdTaskId) return; // skip if create failed

    const res = await request(app)
      .patch(`/api/tasks/${createdTaskId}`)
      .send({ title: "Updated title" })
      .set("Content-Type", "application/json");

    assert.equal(res.status, 200);
    assert.equal((res.body as { title: string }).title, "Updated title");
  });

  it("returns 404 when updating a non-existent task", async () => {
    const res = await request(app)
      .patch("/api/tasks/99999999")
      .send({ title: "Ghost task" })
      .set("Content-Type", "application/json");

    assert.equal(res.status, 404);
  });

  // ─── PATCH /api/tasks/:id/toggle ──────────────────────────────────────────

  it("toggles task completion via PATCH /:id/toggle", async () => {
    if (!createdTaskId) return;

    const res = await request(app).patch(`/api/tasks/${createdTaskId}/toggle`);

    assert.equal(res.status, 200);
    assert.equal((res.body as { completed: boolean }).completed, true);
  });

  // ─── DELETE /api/tasks/:id ─────────────────────────────────────────────────

  it("deletes the created task and returns 204", async () => {
    if (!createdTaskId) return;

    const res = await request(app).delete(`/api/tasks/${createdTaskId}`);
    assert.equal(res.status, 204);
  });

  it("returns 404 when deleting a non-existent task", async () => {
    const res = await request(app).delete("/api/tasks/99999999");
    assert.equal(res.status, 404);
  });
});

// ─── CSV Export ───────────────────────────────────────────────────────────────

describe("GET /api/tasks/export", () => {
  it("returns a CSV file with Content-Type text/csv", async () => {
    const res = await request(app).get("/api/tasks/export");

    assert.equal(res.status, 200);
    assert.ok(
      res.headers["content-type"]?.includes("text/csv"),
      `Expected text/csv, got ${res.headers["content-type"]}`,
    );
  });

  it("CSV contains a header row with expected columns", async () => {
    const res = await request(app).get("/api/tasks/export");

    assert.equal(res.status, 200);
    const firstLine = (res.text as string).split("\n")[0]!;
    assert.ok(firstLine.includes("Title"), `Header missing Title: ${firstLine}`);
    assert.ok(firstLine.includes("Priority"), `Header missing Priority: ${firstLine}`);
    assert.ok(firstLine.includes("Completed"), `Header missing Completed: ${firstLine}`);
  });
});

// ─── Bulk operations ──────────────────────────────────────────────────────────

describe("Bulk operations", () => {
  it("PATCH /api/tasks/bulk/complete returns { count: number }", async () => {
    const res = await request(app).patch("/api/tasks/bulk/complete");

    assert.equal(res.status, 200);
    assert.ok(
      typeof (res.body as { count: unknown }).count === "number",
      "Expected count to be a number",
    );
  });

  it("DELETE /api/tasks/bulk/completed returns { count: number }", async () => {
    const res = await request(app).delete("/api/tasks/bulk/completed");

    assert.equal(res.status, 200);
    assert.ok(
      typeof (res.body as { count: unknown }).count === "number",
      "Expected count to be a number",
    );
  });
});
