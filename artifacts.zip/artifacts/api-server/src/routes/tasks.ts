import { Router, type IRouter } from "express";
import { and, asc, desc, eq, ilike, lt, sql } from "drizzle-orm";
import { db, tasksTable } from "@workspace/db";
import {
  ListTasksQueryParams,
  CreateTaskBody,
  GetTaskParams,
  GetTaskResponse,
  UpdateTaskParams,
  UpdateTaskBody,
  UpdateTaskResponse,
  DeleteTaskParams,
  ToggleTaskParams,
  ToggleTaskResponse,
  ListTasksResponse,
  GetTaskStatsResponse,
  ReorderTasksBody,
  ReorderTasksResponse,
  ExportTasksQueryParams,
  BulkCompleteTasksResponse,
  BulkDeleteCompletedResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

// ------------------------------------------------------------------
// GET /tasks
// ------------------------------------------------------------------
router.get("/tasks", async (req, res): Promise<void> => {
  const parsed = ListTasksQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { status, search, priority } = parsed.data;
  const conditions = [];

  if (status === "active") {
    conditions.push(eq(tasksTable.completed, false));
  } else if (status === "completed") {
    conditions.push(eq(tasksTable.completed, true));
  }

  if (search) {
    conditions.push(ilike(tasksTable.title, `%${search}%`));
  }

  if (priority) {
    conditions.push(eq(tasksTable.priority, priority));
  }

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(asc(tasksTable.sortOrder), desc(tasksTable.createdAt));

  res.json(ListTasksResponse.parse(tasks));
});

// ------------------------------------------------------------------
// POST /tasks
// ------------------------------------------------------------------
router.post("/tasks", async (req, res): Promise<void> => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const maxOrderResult = await db
    .select({ maxOrder: sql<number>`coalesce(max(${tasksTable.sortOrder}), -1)` })
    .from(tasksTable);

  const nextOrder = (maxOrderResult[0]?.maxOrder ?? -1) + 1;

  const { dueDate: dueDateRaw, ...restData } = parsed.data;
  const dueDate = dueDateRaw instanceof Date
    ? dueDateRaw.toISOString().split("T")[0]
    : dueDateRaw;

  const [task] = await db
    .insert(tasksTable)
    .values({ ...restData, dueDate: dueDate ?? null, sortOrder: nextOrder })
    .returning();

  res.status(201).json(GetTaskResponse.parse(task));
});

// ------------------------------------------------------------------
// GET /tasks/stats
// ------------------------------------------------------------------
router.get("/tasks/stats", async (_req, res): Promise<void> => {
  const today = new Date().toISOString().split("T")[0];

  const [stats] = await db
    .select({
      total:     sql<number>`count(*)::int`,
      active:    sql<number>`count(*) filter (where ${tasksTable.completed} = false)::int`,
      completed: sql<number>`count(*) filter (where ${tasksTable.completed} = true)::int`,
      overdue:   sql<number>`count(*) filter (where ${tasksTable.completed} = false and ${tasksTable.dueDate} < ${today})::int`,
      pNone:     sql<number>`count(*) filter (where ${tasksTable.priority} = 'none'   and ${tasksTable.completed} = false)::int`,
      pLow:      sql<number>`count(*) filter (where ${tasksTable.priority} = 'low'    and ${tasksTable.completed} = false)::int`,
      pMedium:   sql<number>`count(*) filter (where ${tasksTable.priority} = 'medium' and ${tasksTable.completed} = false)::int`,
      pHigh:     sql<number>`count(*) filter (where ${tasksTable.priority} = 'high'   and ${tasksTable.completed} = false)::int`,
    })
    .from(tasksTable);

  res.json(
    GetTaskStatsResponse.parse({
      total:     stats?.total     ?? 0,
      active:    stats?.active    ?? 0,
      completed: stats?.completed ?? 0,
      overdue:   stats?.overdue   ?? 0,
      byPriority: {
        none:   stats?.pNone   ?? 0,
        low:    stats?.pLow    ?? 0,
        medium: stats?.pMedium ?? 0,
        high:   stats?.pHigh   ?? 0,
      },
    }),
  );
});

// ------------------------------------------------------------------
// GET /tasks/export  → CSV download
// ------------------------------------------------------------------
router.get("/tasks/export", async (req, res): Promise<void> => {
  const parsed = ExportTasksQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { status, priority } = parsed.data;
  const conditions = [];

  if (status === "active") {
    conditions.push(eq(tasksTable.completed, false));
  } else if (status === "completed") {
    conditions.push(eq(tasksTable.completed, true));
  }

  if (priority) {
    conditions.push(eq(tasksTable.priority, priority));
  }

  const tasks = await db
    .select()
    .from(tasksTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(asc(tasksTable.sortOrder), desc(tasksTable.createdAt));

  const escape = (v: string | null | undefined) => {
    if (v === null || v === undefined) return "";
    const s = String(v);
    if (s.includes(",") || s.includes('"') || s.includes("\n")) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  const header = ["ID", "Title", "Description", "Due Date", "Priority", "Completed", "Created At"];
  const rows = tasks.map((t) => [
    t.id,
    escape(t.title),
    escape(t.description),
    t.dueDate ?? "",
    t.priority,
    t.completed ? "Yes" : "No",
    t.createdAt.toISOString(),
  ].join(","));

  const csv = [header.join(","), ...rows].join("\n");
  const filename = `tasks-${new Date().toISOString().split("T")[0]}.csv`;

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  res.send(csv);
});

// ------------------------------------------------------------------
// PATCH /tasks/reorder
// ------------------------------------------------------------------
router.patch("/tasks/reorder", async (req, res): Promise<void> => {
  const parsed = ReorderTasksBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await Promise.all(
    parsed.data.order.map(({ id, sortOrder }) =>
      db.update(tasksTable).set({ sortOrder, updatedAt: new Date() }).where(eq(tasksTable.id, id)),
    ),
  );

  const tasks = await db
    .select()
    .from(tasksTable)
    .orderBy(asc(tasksTable.sortOrder), desc(tasksTable.createdAt));

  res.json(ReorderTasksResponse.parse(tasks));
});

// ------------------------------------------------------------------
// PATCH /tasks/bulk/complete  → mark all active tasks complete
// ------------------------------------------------------------------
router.patch("/tasks/bulk/complete", async (_req, res): Promise<void> => {
  const result = await db
    .update(tasksTable)
    .set({ completed: true, updatedAt: new Date() })
    .where(eq(tasksTable.completed, false))
    .returning({ id: tasksTable.id });

  res.json(BulkCompleteTasksResponse.parse({ count: result.length }));
});

// ------------------------------------------------------------------
// DELETE /tasks/bulk/completed  → delete all completed tasks
// ------------------------------------------------------------------
router.delete("/tasks/bulk/completed", async (_req, res): Promise<void> => {
  const result = await db
    .delete(tasksTable)
    .where(eq(tasksTable.completed, true))
    .returning({ id: tasksTable.id });

  res.json(BulkDeleteCompletedResponse.parse({ count: result.length }));
});

// ------------------------------------------------------------------
// GET /tasks/:id
// ------------------------------------------------------------------
router.get("/tasks/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = GetTaskParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [task] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, params.data.id));

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json(GetTaskResponse.parse(task));
});

// ------------------------------------------------------------------
// PATCH /tasks/:id
// ------------------------------------------------------------------
router.patch("/tasks/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = UpdateTaskParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { dueDate: dueDateRaw, ...restUpdateData } = parsed.data;
  const updateDueDate = dueDateRaw instanceof Date
    ? dueDateRaw.toISOString().split("T")[0]
    : dueDateRaw;

  const [task] = await db
    .update(tasksTable)
    .set({
      ...restUpdateData,
      ...(dueDateRaw !== undefined ? { dueDate: updateDueDate } : {}),
      updatedAt: new Date(),
    })
    .where(eq(tasksTable.id, params.data.id))
    .returning();

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.json(UpdateTaskResponse.parse(task));
});

// ------------------------------------------------------------------
// DELETE /tasks/:id
// ------------------------------------------------------------------
router.delete("/tasks/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = DeleteTaskParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [task] = await db
    .delete(tasksTable)
    .where(eq(tasksTable.id, params.data.id))
    .returning();

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  res.sendStatus(204);
});

// ------------------------------------------------------------------
// PATCH /tasks/:id/toggle
// ------------------------------------------------------------------
router.patch("/tasks/:id/toggle", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const params = ToggleTaskParams.safeParse({ id: parseInt(raw, 10) });
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, params.data.id));

  if (!existing) {
    res.status(404).json({ error: "Task not found" });
    return;
  }

  const [task] = await db
    .update(tasksTable)
    .set({ completed: !existing.completed, updatedAt: new Date() })
    .where(eq(tasksTable.id, params.data.id))
    .returning();

  res.json(ToggleTaskResponse.parse(task));
});

export default router;
