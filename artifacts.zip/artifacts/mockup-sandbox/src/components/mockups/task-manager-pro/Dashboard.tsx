import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  Search, 
  Bell, 
  Plus, 
  Calendar, 
  LayoutDashboard, 
  CheckSquare, 
  Settings, 
  MoreVertical,
  GripVertical,
  Clock,
  Trash2,
  Edit2,
  AlertCircle
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const tasks = [
  {
    id: 1,
    title: 'Set up project repository',
    date: 'May 28, 2026',
    status: 'overdue',
    completed: false
  },
  {
    id: 2,
    title: 'Design database schema',
    date: 'May 28, 2026',
    status: 'overdue',
    completed: false
  },
  {
    id: 3,
    title: 'Build REST API endpoints',
    date: 'Jun 3, 2026',
    status: 'overdue',
    completed: false
  },
  {
    id: 4,
    title: 'Write React frontend',
    description: 'Create the main dashboard and components',
    date: 'Jun 4, 2026',
    status: 'today',
    completed: false
  },
  {
    id: 5,
    title: 'Add drag-and-drop reordering',
    date: 'Jun 5, 2026',
    status: 'upcoming',
    completed: false
  },
  {
    id: 6,
    title: 'Implement search functionality',
    date: 'Jun 11, 2026',
    status: 'upcoming',
    completed: false
  },
  {
    id: 7,
    title: 'Deploy to production',
    date: 'Jun 11, 2026',
    status: 'upcoming',
    completed: false
  }
];

export function Dashboard() {
  const [activeTab, setActiveTab] = useState('All');
  
  return (
    <div className="flex h-screen w-full bg-[#F8FAFC] font-sans text-slate-800" style={{ fontFamily: "'Inter', sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
      `}</style>
      
      {/* Sidebar */}
      <aside className="w-[240px] flex-shrink-0 bg-[#0F172A] text-slate-300 flex flex-col h-full shadow-xl z-20">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-500/20">
            F
          </div>
          <span className="text-white text-xl font-bold tracking-tight">Focus</span>
        </div>
        
        <div className="flex-1 py-6 px-4 space-y-2">
          <nav className="space-y-1">
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors">
              <LayoutDashboard size={18} />
              <span className="font-medium text-sm">Dashboard</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-white bg-slate-800/80 relative transition-colors shadow-sm">
              <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#2563EB] rounded-r-full"></div>
              <CheckSquare size={18} className="text-[#2563EB]" />
              <span className="font-medium text-sm">My Tasks</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors">
              <CheckCircle2 size={18} />
              <span className="font-medium text-sm">Completed</span>
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors">
              <Calendar size={18} />
              <span className="font-medium text-sm">Calendar</span>
            </a>
          </nav>
        </div>
        
        <div className="mt-auto p-4 border-t border-slate-800">
          <a href="#" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors mb-4">
            <Settings size={18} />
            <span className="font-medium text-sm">Settings</span>
          </a>
          
          <div className="flex items-center gap-3 px-3 py-2 hover:bg-slate-800/50 rounded-lg cursor-pointer transition-colors">
            <Avatar className="h-9 w-9 border-2 border-slate-700">
              <AvatarImage src="/__mockup/images/avatar.jpg" />
              <AvatarFallback className="bg-slate-800 text-white">JD</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-white">Jane Doe</span>
              <span className="text-xs text-slate-400">jane@example.com</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Header */}
        <header className="h-[72px] bg-white border-b border-slate-200 px-8 flex items-center justify-between flex-shrink-0 z-10 shadow-sm">
          <div className="flex items-center gap-4 flex-1">
            <div>
              <h1 className="text-xl font-bold text-slate-900">My Tasks</h1>
              <p className="text-xs font-medium text-slate-500 mt-0.5">Organize and prioritize your work</p>
            </div>
          </div>
          
          <div className="flex items-center gap-5">
            <div className="relative w-64 hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input 
                placeholder="Search tasks..." 
                className="pl-9 bg-slate-50 border-slate-200 focus-visible:ring-[#2563EB] h-10 rounded-lg"
              />
            </div>
            
            <Button size="icon" variant="ghost" className="relative text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-full h-10 w-10">
              <Bell size={20} />
              <span className="absolute top-2 right-2.5 w-2 h-2 bg-[#EF4444] rounded-full ring-2 ring-white"></span>
            </Button>
            
            <Button className="bg-[#2563EB] hover:bg-blue-700 text-white rounded-lg h-10 px-4 shadow-md shadow-blue-500/20 font-medium">
              <Plus size={18} className="mr-2" />
              New Task
            </Button>
          </div>
        </header>

        {/* Content Scroll Area */}
        <div className="flex-1 overflow-auto p-8">
          <div className="max-w-5xl mx-auto space-y-8">
            
            {/* Stats Row */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
                  <CheckSquare size={24} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500">Total Tasks</p>
                  <p className="text-2xl font-bold text-slate-900">7</p>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex items-center gap-4 relative overflow-hidden">
                <div className="absolute inset-0 bg-blue-50/50"></div>
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center text-[#2563EB] relative z-10">
                  <Clock size={24} />
                </div>
                <div className="relative z-10">
                  <p className="text-sm font-medium text-slate-500">Active Tasks</p>
                  <p className="text-2xl font-bold text-slate-900">4</p>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex items-center gap-4 relative overflow-hidden">
                <div className="absolute inset-0 bg-emerald-50/50"></div>
                <div className="w-12 h-12 rounded-lg bg-emerald-100 flex items-center justify-center text-[#22C55E] relative z-10">
                  <CheckCircle2 size={24} />
                </div>
                <div className="relative z-10">
                  <p className="text-sm font-medium text-slate-500">Completed</p>
                  <p className="text-2xl font-bold text-slate-900">0</p>
                </div>
              </div>
              
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex items-center gap-4 relative overflow-hidden">
                <div className="absolute inset-0 bg-red-50/50"></div>
                <div className="w-12 h-12 rounded-lg bg-red-100 flex items-center justify-center text-[#EF4444] relative z-10">
                  <AlertCircle size={24} />
                </div>
                <div className="relative z-10">
                  <p className="text-sm font-medium text-slate-500">Overdue</p>
                  <p className="text-2xl font-bold text-slate-900">3</p>
                </div>
              </div>
            </div>

            {/* Task List Section */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-bold text-slate-900">Current Tasks</h2>
                <div className="flex bg-slate-200/50 p-1 rounded-lg">
                  {['All', 'Active', 'Completed'].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                        activeTab === tab 
                          ? 'bg-white text-[#2563EB] shadow-sm' 
                          : 'text-slate-500 hover:text-slate-700'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                {tasks.map((task) => (
                  <div 
                    key={task.id}
                    className={`group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex items-center p-4 relative overflow-hidden
                      ${task.status === 'overdue' ? 'border-l-[3px] border-l-[#EF4444]' : ''}
                      ${task.status === 'today' ? 'border-l-[3px] border-l-[#F59E0B]' : ''}
                      ${task.status === 'upcoming' ? 'border-l-[3px] border-l-transparent' : ''}
                    `}
                  >
                    <button className="text-slate-300 hover:text-slate-500 cursor-grab active:cursor-grabbing px-2 py-4 -ml-2 mr-1">
                      <GripVertical size={16} />
                    </button>
                    
                    <button className="text-slate-300 hover:text-[#22C55E] transition-colors mr-4 flex-shrink-0">
                      <Circle size={22} strokeWidth={2} />
                    </button>
                    
                    <div className="flex-1 min-w-0 mr-4">
                      <h3 className="text-[15px] font-semibold text-slate-800 truncate leading-snug">
                        {task.title}
                      </h3>
                      {task.description && (
                        <p className="text-sm text-slate-500 truncate mt-0.5">
                          {task.description}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3 ml-auto">
                      {task.status === 'overdue' && (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold bg-red-100 text-[#EF4444] uppercase tracking-wider">
                          <AlertCircle size={12} />
                          Overdue
                        </span>
                      )}
                      
                      <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium
                        ${task.status === 'overdue' ? 'text-[#EF4444] bg-red-50/50' : ''}
                        ${task.status === 'today' ? 'text-[#F59E0B] bg-amber-50/50' : ''}
                        ${task.status === 'upcoming' ? 'text-slate-500 bg-slate-50' : ''}
                      `}>
                        <Calendar size={14} className={task.status === 'overdue' ? 'text-[#EF4444]' : 'text-slate-400'} />
                        {task.date}
                      </div>
                      
                      <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity ml-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-[#2563EB] hover:bg-blue-50">
                          <Edit2 size={16} />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-[#EF4444] hover:bg-red-50">
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
          </div>
        </div>
      </main>
    </div>
  );
}
