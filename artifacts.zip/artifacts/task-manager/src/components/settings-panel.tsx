import { useState } from "react";
import {
  X, User, Bell, Palette, Database, Info,
  CheckCircle2, Moon, Sun, Monitor, Download,
  Trash2, Shield, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { User as UserType } from "@/pages/home";

interface Props {
  open: boolean;
  onClose: () => void;
  currentUser: UserType | null;
  onUpdateUser: (user: UserType) => void;
  onExport: () => void;
}

type Section = "profile" | "appearance" | "notifications" | "data" | "about";

const SECTIONS: { id: Section; icon: React.ElementType; label: string }[] = [
  { id: "profile",       icon: User,        label: "Profile" },
  { id: "appearance",    icon: Palette,     label: "Appearance" },
  { id: "notifications", icon: Bell,        label: "Notifications" },
  { id: "data",          icon: Database,    label: "Data & Export" },
  { id: "about",         icon: Info,        label: "About" },
];

type Theme = "light" | "dark" | "system";

export function SettingsPanel({ open, onClose, currentUser, onUpdateUser, onExport }: Props) {
  const [activeSection, setActiveSection] = useState<Section>("profile");
  const [name, setName]                   = useState(currentUser?.name ?? "");
  const [email, setEmail]                 = useState(currentUser?.email ?? "");
  const [saved, setSaved]                 = useState(false);
  const [theme, setTheme]                 = useState<Theme>("light");
  const [notifOverdue, setNotifOverdue]   = useState(true);
  const [notifDueToday, setNotifDueToday] = useState(true);
  const [notifSummary, setNotifSummary]   = useState(false);
  const [confirmClear, setConfirmClear]   = useState(false);

  const handleSaveProfile = () => {
    if (!name.trim()) return;
    const initials = name.trim().split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();
    onUpdateUser({ name: name.trim(), email: email.trim(), initials });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-40 bg-black/20 backdrop-blur-[2px]" onClick={onClose} />
      )}

      <div
        className={cn(
          "fixed top-0 right-0 h-full w-[520px] bg-white border-l border-slate-200 shadow-2xl z-50 flex overflow-hidden transition-transform duration-300",
          open ? "translate-x-0" : "translate-x-full"
        )}
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        {/* ── Sidebar nav ───────────────────────────── */}
        <div className="w-[160px] bg-slate-50 border-r border-slate-200 flex flex-col flex-shrink-0">
          <div className="px-4 py-5 border-b border-slate-200">
            <h2 className="text-sm font-bold text-slate-800">Settings</h2>
          </div>
          <nav className="flex-1 py-3 px-2 space-y-0.5">
            {SECTIONS.map(({ id, icon: Icon, label }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-left",
                  activeSection === id
                    ? "bg-white text-[#2563EB] shadow-sm border border-slate-200"
                    : "text-slate-600 hover:bg-white hover:text-slate-900"
                )}
              >
                <Icon size={15} className={activeSection === id ? "text-[#2563EB]" : "text-slate-400"} />
                {label}
              </button>
            ))}
          </nav>
        </div>

        {/* ── Content ───────────────────────────────── */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100">
            <h3 className="text-base font-semibold text-slate-900">
              {SECTIONS.find((s) => s.id === activeSection)?.label}
            </h3>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
            >
              <X size={16} />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">

            {/* ── Profile ── */}
            {activeSection === "profile" && (
              <>
                {/* Avatar */}
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-[#2563EB] text-white text-2xl font-bold flex items-center justify-center shadow-md shadow-blue-500/20">
                    {name ? name.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase() : "?"}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{name || "Your Name"}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{email || "your@email.com"}</p>
                    <span className="text-xs text-[#2563EB] font-medium bg-blue-50 px-2 py-0.5 rounded-full mt-1 inline-block">Personal workspace</span>
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">Display name</label>
                    <Input
                      value={name}
                      onChange={(e) => { setName(e.target.value); setSaved(false); }}
                      placeholder="Your name"
                      className="h-10 text-sm border-slate-300 focus-visible:ring-[#2563EB]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">Email address</label>
                    <Input
                      value={email}
                      onChange={(e) => { setEmail(e.target.value); setSaved(false); }}
                      placeholder="you@company.com"
                      type="email"
                      className="h-10 text-sm border-slate-300 focus-visible:ring-[#2563EB]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1.5">Role</label>
                    <Input
                      defaultValue="Personal workspace"
                      disabled
                      className="h-10 text-sm border-slate-200 bg-slate-50 text-slate-400"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleSaveProfile}
                  disabled={!name.trim()}
                  className={cn(
                    "w-full h-10 font-semibold text-sm transition-all",
                    saved
                      ? "bg-emerald-500 hover:bg-emerald-600 text-white"
                      : "bg-[#2563EB] hover:bg-blue-700 text-white shadow-sm shadow-blue-500/20"
                  )}
                >
                  {saved ? (
                    <span className="flex items-center gap-2"><CheckCircle2 size={16} />Saved!</span>
                  ) : "Save changes"}
                </Button>
              </>
            )}

            {/* ── Appearance ── */}
            {activeSection === "appearance" && (
              <>
                <div>
                  <p className="text-sm font-semibold text-slate-800 mb-1">Theme</p>
                  <p className="text-xs text-slate-500 mb-4">Choose how Focus looks on your device.</p>
                  <div className="grid grid-cols-3 gap-3">
                    {([
                      { id: "light",  icon: Sun,     label: "Light" },
                      { id: "dark",   icon: Moon,    label: "Dark" },
                      { id: "system", icon: Monitor, label: "System" },
                    ] as { id: Theme; icon: React.ElementType; label: string }[]).map(({ id, icon: Icon, label }) => (
                      <button
                        key={id}
                        onClick={() => setTheme(id)}
                        className={cn(
                          "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all",
                          theme === id
                            ? "border-[#2563EB] bg-blue-50/50 text-[#2563EB]"
                            : "border-slate-200 hover:border-slate-300 text-slate-500"
                        )}
                      >
                        <Icon size={20} />
                        <span className="text-xs font-semibold">{label}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                <div>
                  <p className="text-sm font-semibold text-slate-800 mb-1">Accent color</p>
                  <p className="text-xs text-slate-500 mb-4">Customize the highlight color across the app.</p>
                  <div className="flex gap-3 flex-wrap">
                    {[
                      { color: "bg-[#2563EB]", label: "Blue",   active: true },
                      { color: "bg-violet-600", label: "Violet", active: false },
                      { color: "bg-emerald-600", label: "Green", active: false },
                      { color: "bg-rose-600",   label: "Rose",  active: false },
                      { color: "bg-amber-500",  label: "Amber", active: false },
                    ].map(({ color, label, active }) => (
                      <button
                        key={label}
                        title={label}
                        className={cn(
                          "w-8 h-8 rounded-full transition-all",
                          color,
                          active ? "ring-2 ring-offset-2 ring-[#2563EB] scale-110" : "hover:scale-110 opacity-70 hover:opacity-100"
                        )}
                      />
                    ))}
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                <ToggleRow
                  label="Compact mode"
                  description="Reduce spacing between task items."
                  checked={false}
                  onChange={() => {}}
                />
                <ToggleRow
                  label="Show task descriptions"
                  description="Display description text in task cards."
                  checked={true}
                  onChange={() => {}}
                />
              </>
            )}

            {/* ── Notifications ── */}
            {activeSection === "notifications" && (
              <>
                <div>
                  <p className="text-sm font-semibold text-slate-800 mb-1">In-app alerts</p>
                  <p className="text-xs text-slate-500 mb-4">Control what shows up in your notifications panel.</p>
                </div>

                <div className="space-y-4">
                  <ToggleRow
                    label="Overdue tasks"
                    description="Alert when tasks pass their due date."
                    checked={notifOverdue}
                    onChange={setNotifOverdue}
                  />
                  <ToggleRow
                    label="Due today"
                    description="Show tasks due on the current day."
                    checked={notifDueToday}
                    onChange={setNotifDueToday}
                  />
                  <ToggleRow
                    label="Weekly summary"
                    description="Show a summary of the week's progress."
                    checked={notifSummary}
                    onChange={setNotifSummary}
                  />
                </div>

                <div className="h-px bg-slate-100" />

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
                  <p className="text-xs font-semibold text-amber-800 mb-1">Email notifications</p>
                  <p className="text-xs text-amber-700">Email reminders are not available in this workspace. Upgrade to a team plan to enable them.</p>
                </div>
              </>
            )}

            {/* ── Data & Export ── */}
            {activeSection === "data" && (
              <>
                <div>
                  <p className="text-sm font-semibold text-slate-800 mb-1">Export your data</p>
                  <p className="text-xs text-slate-500 mb-4">Download a copy of all your tasks in CSV format.</p>
                  <button
                    onClick={() => { onExport(); }}
                    className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-slate-200 bg-white hover:border-[#2563EB] hover:bg-blue-50/30 transition-all text-left group"
                  >
                    <div className="w-9 h-9 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Download size={17} className="text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-800 group-hover:text-[#2563EB] transition-colors">Download all tasks (CSV)</p>
                      <p className="text-xs text-slate-500">Includes title, description, status, priority, due date</p>
                    </div>
                    <ChevronRight size={15} className="ml-auto text-slate-300 group-hover:text-[#2563EB] transition-colors" />
                  </button>
                </div>

                <div className="h-px bg-slate-100" />

                <div>
                  <p className="text-sm font-semibold text-slate-800 mb-1">Danger zone</p>
                  <p className="text-xs text-slate-500 mb-4">Permanent actions that cannot be undone.</p>

                  {!confirmClear ? (
                    <button
                      onClick={() => setConfirmClear(true)}
                      className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl border border-red-200 bg-red-50/50 hover:bg-red-50 hover:border-red-300 transition-all text-left group"
                    >
                      <div className="w-9 h-9 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Trash2 size={17} className="text-red-500" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-red-700">Clear completed tasks</p>
                        <p className="text-xs text-red-500">Permanently delete all completed tasks</p>
                      </div>
                    </button>
                  ) : (
                    <div className="border border-red-300 bg-red-50 rounded-xl p-4">
                      <p className="text-sm font-semibold text-red-800 mb-1">Are you sure?</p>
                      <p className="text-xs text-red-600 mb-4">This will permanently delete all completed tasks. This cannot be undone.</p>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 border-slate-300 text-slate-700 h-9"
                          onClick={() => setConfirmClear(false)}
                        >
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white h-9"
                          onClick={() => setConfirmClear(false)}
                        >
                          Delete all
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* ── About ── */}
            {activeSection === "about" && (
              <>
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-[#2563EB] text-white text-2xl font-bold flex items-center justify-center shadow-lg shadow-blue-500/20">
                    F
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">Focus</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Personal Task Manager · v1.0.0</p>
                  </div>
                </div>

                <div className="h-px bg-slate-100" />

                <div className="space-y-3">
                  {[
                    { label: "Version",     value: "1.0.0" },
                    { label: "Framework",   value: "React 19 + Vite 7" },
                    { label: "Backend",     value: "Express 5 + PostgreSQL" },
                    { label: "ORM",         value: "Drizzle ORM" },
                    { label: "Build",       value: "pnpm monorepo" },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
                      <span className="text-sm text-slate-500">{label}</span>
                      <span className="text-sm font-medium text-slate-800">{value}</span>
                    </div>
                  ))}
                </div>

                <div className="h-px bg-slate-100" />

                <div className="bg-slate-50 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Shield size={14} className="text-slate-500" />
                    <p className="text-xs font-semibold text-slate-700">Privacy</p>
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    All data is stored in a shared PostgreSQL database. No personal data is collected. This app is a demonstration project.
                  </p>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

/* ── Toggle row ──────────────────────────────────────── */
function ToggleRow({
  label, description, checked, onChange,
}: {
  label: string; description: string; checked: boolean; onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-sm font-medium text-slate-800">{label}</p>
        <p className="text-xs text-slate-500 mt-0.5">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={cn(
          "flex-shrink-0 w-11 h-6 rounded-full transition-colors duration-200 relative mt-0.5",
          checked ? "bg-[#2563EB]" : "bg-slate-200"
        )}
      >
        <span className={cn(
          "absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform duration-200",
          checked ? "translate-x-6" : "translate-x-1"
        )} />
      </button>
    </div>
  );
}
