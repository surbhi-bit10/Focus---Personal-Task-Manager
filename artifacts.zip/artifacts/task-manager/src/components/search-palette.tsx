import { useState, useEffect, useRef, useMemo } from "react";
import { Search, CheckCircle2, Circle, Calendar, Flag, X, Loader2 } from "lucide-react";
import { format, isPast, isToday, parseISO, startOfDay } from "date-fns";
import { cn } from "@/lib/utils";
import type { Task } from "@workspace/api-client-react";

interface Props {
  open: boolean;
  onClose: () => void;
  allTasks: Task[];
  onNavigateTasks: () => void;
}

const PRIORITY_DOT: Record<string, string> = {
  high:   "text-red-500",
  medium: "text-amber-400",
  low:    "text-sky-400",
  none:   "text-slate-300",
};

export function SearchPalette({ open, onClose, allTasks, onNavigateTasks }: Props) {
  const [query, setQuery]       = useState("");
  const inputRef                = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQuery("");
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return allTasks.slice(0, 8);
    return allTasks.filter((t) =>
      t.title.toLowerCase().includes(q) ||
      (t.description ?? "").toLowerCase().includes(q)
    ).slice(0, 12);
  }, [query, allTasks]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh]"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" />

      {/* Palette */}
      <div
        className="relative w-full max-w-[580px] mx-4 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        {/* Input */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100">
          <Search size={18} className="text-slate-400 flex-shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search tasks by title or description…"
            className="flex-1 text-base text-slate-900 placeholder:text-slate-400 outline-none bg-transparent"
          />
          {query && (
            <button onClick={() => setQuery("")} className="text-slate-400 hover:text-slate-600 transition-colors">
              <X size={16} />
            </button>
          )}
          <kbd className="text-[11px] bg-slate-100 border border-slate-200 rounded px-1.5 py-1 font-mono text-slate-500">Esc</kbd>
        </div>

        {/* Section label */}
        <div className="px-5 py-2 bg-slate-50/70 border-b border-slate-100">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            {query ? `${results.length} result${results.length !== 1 ? "s" : ""}` : "Recent tasks"}
          </p>
        </div>

        {/* Results */}
        <div className="max-h-[400px] overflow-y-auto">
          {results.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Search size={28} className="text-slate-300 mb-3" />
              <p className="text-sm font-medium text-slate-500">No tasks found</p>
              <p className="text-xs text-slate-400 mt-1">Try a different search term</p>
            </div>
          ) : (
            results.map((t) => {
              const p       = (t.priority ?? "none") as keyof typeof PRIORITY_DOT;
              const parsedD = t.dueDate ? parseISO(t.dueDate) : null;
              const isOv    = parsedD && !t.completed && isPast(startOfDay(parsedD)) && !isToday(parsedD);
              const isTod   = parsedD && isToday(parsedD);

              // Highlight matching text
              const highlight = (text: string) => {
                if (!query.trim()) return <span>{text}</span>;
                const regex = new RegExp(`(${query.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
                const parts = text.split(regex);
                return (
                  <>
                    {parts.map((part, i) =>
                      regex.test(part) ? (
                        <mark key={i} className="bg-yellow-100 text-yellow-800 rounded px-0.5">{part}</mark>
                      ) : (
                        <span key={i}>{part}</span>
                      )
                    )}
                  </>
                );
              };

              return (
                <div
                  key={t.id}
                  className="flex items-center gap-3 px-5 py-3.5 hover:bg-slate-50 transition-colors cursor-pointer border-b border-slate-50 last:border-0"
                  onClick={() => { onNavigateTasks(); onClose(); }}
                >
                  {/* Check icon */}
                  {t.completed ? (
                    <CheckCircle2 size={18} className="text-[#22C55E] flex-shrink-0" />
                  ) : (
                    <Circle size={18} className={cn("flex-shrink-0", isOv ? "text-red-400" : "text-slate-300")} />
                  )}

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <p className={cn(
                      "text-sm font-medium leading-snug",
                      t.completed ? "line-through text-slate-400" : isOv ? "text-red-600" : "text-slate-800"
                    )}>
                      {highlight(t.title)}
                    </p>
                    {t.description && (
                      <p className="text-xs text-slate-400 truncate mt-0.5">{highlight(t.description)}</p>
                    )}
                  </div>

                  {/* Meta */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {isOv && (
                      <span className="text-[11px] text-red-500 bg-red-50 px-1.5 py-0.5 rounded font-bold uppercase tracking-wide">
                        Overdue
                      </span>
                    )}
                    {t.dueDate && !isOv && (
                      <span className={cn(
                        "text-[11px] px-1.5 py-0.5 rounded font-medium flex items-center gap-1",
                        isTod ? "text-amber-600 bg-amber-50" : "text-slate-500 bg-slate-50"
                      )}>
                        <Calendar size={10} />
                        {isTod ? "Today" : format(parseISO(t.dueDate), "MMM d")}
                      </span>
                    )}
                    <Flag size={12} className={PRIORITY_DOT[p]} />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer hint */}
        <div className="px-5 py-3 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <kbd className="bg-white border border-slate-200 rounded px-1 py-0.5 font-mono">↵</kbd>
              Open in tasks
            </span>
          </div>
          <span className="text-[11px] text-slate-400">{allTasks.length} total tasks</span>
        </div>
      </div>
    </div>
  );
}
