import { useState, useMemo } from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval,
         getDay, isSameDay, isToday, isPast, parseISO, startOfDay,
         addMonths, subMonths, isSameMonth } from "date-fns";
import { ChevronLeft, ChevronRight, Plus, Calendar, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Task } from "@workspace/api-client-react";

interface Props {
  allTasks: Task[];
  onCreateTask: () => void;
}

const PRIORITY_DOT: Record<string, string> = {
  high:   "bg-red-500",
  medium: "bg-amber-400",
  low:    "bg-sky-400",
  none:   "bg-slate-400",
};

export function CalendarView({ allTasks, onCreateTask }: Props) {
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<Date | null>(new Date());

  const monthStart = startOfMonth(viewDate);
  const monthEnd   = endOfMonth(viewDate);

  // Days of month
  const days       = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Leading blank cells for first day offset (Mon=0)
  const startDow   = (getDay(monthStart) + 6) % 7; // 0=Mon
  const blanks     = Array.from({ length: startDow });

  // Group tasks by due date
  const tasksByDay = useMemo(() => {
    const map = new Map<string, Task[]>();
    allTasks.forEach((t) => {
      if (!t.dueDate) return;
      const key = t.dueDate.slice(0, 10);
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(t);
    });
    return map;
  }, [allTasks]);

  const selectedKey   = selectedDay ? format(selectedDay, "yyyy-MM-dd") : null;
  const selectedTasks = selectedKey ? (tasksByDay.get(selectedKey) ?? []) : [];

  const DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const totalThisMonth = useMemo(() => {
    return allTasks.filter((t) => t.dueDate && isSameMonth(parseISO(t.dueDate), viewDate)).length;
  }, [allTasks, viewDate]);

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">

        {/* ── Calendar grid ──────────────────────────── */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {/* Month nav */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <div>
              <h2 className="text-lg font-bold text-slate-900">{format(viewDate, "MMMM yyyy")}</h2>
              <p className="text-xs text-slate-500 mt-0.5">{totalThisMonth} task{totalThisMonth !== 1 ? "s" : ""} this month</p>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setViewDate(subMonths(viewDate, 1))}
                className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 transition-colors"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={() => setViewDate(new Date())}
                className="h-8 px-3 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors"
              >
                Today
              </button>
              <button
                onClick={() => setViewDate(addMonths(viewDate, 1))}
                className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500 hover:text-slate-800 transition-colors"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>

          {/* Day-of-week header */}
          <div className="grid grid-cols-7 border-b border-slate-100">
            {DOW.map((d) => (
              <div key={d} className="py-3 text-center text-xs font-semibold text-slate-400 uppercase tracking-wide">
                {d}
              </div>
            ))}
          </div>

          {/* Day cells */}
          <div className="grid grid-cols-7">
            {blanks.map((_, i) => (
              <div key={`blank-${i}`} className="h-24 border-b border-r border-slate-50 last:border-r-0" />
            ))}
            {days.map((day, i) => {
              const key       = format(day, "yyyy-MM-dd");
              const dayTasks  = tasksByDay.get(key) ?? [];
              const isSelected = selectedDay ? isSameDay(day, selectedDay) : false;
              const today     = isToday(day);
              const colIdx    = (startDow + i) % 7;
              const isLastCol = colIdx === 6;
              const hasOverdue = dayTasks.some((t) => !t.completed && isPast(startOfDay(day)) && !today);

              return (
                <button
                  key={key}
                  onClick={() => setSelectedDay(isSameDay(day, selectedDay ?? new Date(-1)) ? null : day)}
                  className={cn(
                    "h-24 p-2 flex flex-col border-b border-r border-slate-50 transition-colors text-left hover:bg-slate-50",
                    isLastCol && "border-r-0",
                    isSelected && "bg-blue-50/60 hover:bg-blue-50/80",
                    today && !isSelected && "bg-amber-50/40"
                  )}
                >
                  {/* Day number */}
                  <span className={cn(
                    "w-7 h-7 rounded-full flex items-center justify-center text-sm font-semibold mb-1 flex-shrink-0 transition-colors",
                    today && !isSelected && "bg-[#2563EB] text-white",
                    isSelected && !today && "bg-[#2563EB] text-white",
                    !today && !isSelected && "text-slate-700",
                  )}>
                    {format(day, "d")}
                  </span>

                  {/* Task dots */}
                  <div className="flex flex-wrap gap-1 flex-1 content-start overflow-hidden">
                    {dayTasks.slice(0, 4).map((t, idx) => {
                      const p    = (t.priority ?? "none") as keyof typeof PRIORITY_DOT;
                      const isOv = !t.completed && isPast(startOfDay(day)) && !today;
                      return (
                        <span
                          key={t.id}
                          title={t.title}
                          className={cn(
                            "w-full flex items-center gap-1 text-[10px] truncate px-1 py-0.5 rounded leading-none",
                            t.completed
                              ? "bg-slate-100 text-slate-400 line-through"
                              : isOv
                              ? "bg-red-100 text-red-600"
                              : "bg-slate-100 text-slate-600"
                          )}
                        >
                          <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", isOv ? "bg-red-500" : PRIORITY_DOT[p])} />
                          <span className="truncate">{t.title}</span>
                        </span>
                      );
                    })}
                    {dayTasks.length > 4 && (
                      <span className="text-[10px] text-slate-400 font-medium px-1">+{dayTasks.length - 4}</span>
                    )}
                  </div>

                  {hasOverdue && dayTasks.some((t) => !t.completed) && (
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 absolute" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* ── Day panel ──────────────────────────────── */}
        <div className="space-y-4">
          {/* Legend */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
            <p className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-3">Priority</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "High",   dot: "bg-red-500" },
                { label: "Medium", dot: "bg-amber-400" },
                { label: "Low",    dot: "bg-sky-400" },
                { label: "None",   dot: "bg-slate-400" },
              ].map(({ label, dot }) => (
                <div key={label} className="flex items-center gap-1.5 text-xs text-slate-500">
                  <span className={cn("w-2 h-2 rounded-full", dot)} />
                  {label}
                </div>
              ))}
            </div>
          </div>

          {/* Selected day panel */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex-1">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">
                  {selectedDay ? format(selectedDay, "EEEE, MMMM d") : "Select a day"}
                </p>
                {selectedDay && (
                  <p className="text-xs text-slate-500 mt-0.5">
                    {selectedTasks.length} task{selectedTasks.length !== 1 ? "s" : ""}
                  </p>
                )}
              </div>
              <Button
                size="sm"
                onClick={onCreateTask}
                className="bg-[#2563EB] hover:bg-blue-700 text-white h-8 px-3 text-xs"
              >
                <Plus size={13} className="mr-1" />
                Add
              </Button>
            </div>

            <div className="p-4 space-y-2 max-h-[440px] overflow-y-auto">
              {!selectedDay ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Calendar size={32} className="text-slate-300 mb-3" />
                  <p className="text-sm text-slate-400">Click a day to see tasks</p>
                </div>
              ) : selectedTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center mb-3">
                    <Calendar size={18} className="text-slate-400" />
                  </div>
                  <p className="text-sm text-slate-500 font-medium">No tasks for this day</p>
                  <button
                    onClick={onCreateTask}
                    className="text-xs text-[#2563EB] hover:text-blue-700 mt-2 font-medium transition-colors"
                  >
                    + Add a task
                  </button>
                </div>
              ) : (
                selectedTasks.map((t) => {
                  const p    = (t.priority ?? "none") as keyof typeof PRIORITY_DOT;
                  const isOv = selectedDay && !t.completed &&
                    isPast(startOfDay(selectedDay)) && !isToday(selectedDay);

                  return (
                    <div
                      key={t.id}
                      className={cn(
                        "flex items-start gap-3 p-3 rounded-xl border transition-colors",
                        t.completed
                          ? "border-slate-100 bg-slate-50/50"
                          : isOv
                          ? "border-red-100 bg-red-50/50"
                          : "border-slate-100 bg-white hover:bg-slate-50"
                      )}
                    >
                      <span className={cn("w-2.5 h-2.5 rounded-full flex-shrink-0 mt-1", isOv ? "bg-red-500" : PRIORITY_DOT[p])} />
                      <div className="flex-1 min-w-0">
                        <p className={cn(
                          "text-sm font-medium leading-snug",
                          t.completed ? "line-through text-slate-400" : isOv ? "text-red-700" : "text-slate-800"
                        )}>
                          {t.title}
                        </p>
                        {t.description && (
                          <p className="text-xs text-slate-400 mt-0.5 truncate">{t.description}</p>
                        )}
                        <div className="flex items-center gap-2 mt-1.5">
                          {t.completed && (
                            <span className="text-[11px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-medium">Done</span>
                          )}
                          {isOv && !t.completed && (
                            <span className="text-[11px] text-red-600 bg-red-100 px-1.5 py-0.5 rounded font-bold uppercase tracking-wide flex items-center gap-1">
                              <AlertCircle size={9} />Overdue
                            </span>
                          )}
                          <span className="text-[11px] text-slate-400 capitalize">{t.priority !== "none" ? t.priority + " priority" : ""}</span>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
