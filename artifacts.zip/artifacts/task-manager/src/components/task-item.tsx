import { useState } from "react";
import { format, isPast, isToday, parseISO, startOfDay } from "date-fns";
import { GripVertical, Pencil, Trash2, Calendar, AlertCircle, CheckCircle2, Circle, Flag } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { TaskForm } from "./task-form";

import { useToggleTask, useDeleteTask } from "@workspace/api-client-react";
import type { Task } from "@workspace/api-client-react";

interface TaskItemProps {
  task: Task;
  index: number;
  onDragStart: (e: React.DragEvent, index: number) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, index: number) => void;
  isDragging: boolean;
}

const PRIORITY_CONFIG = {
  none:   { label: null,     color: "text-slate-300",  bg: "" },
  low:    { label: "Low",    color: "text-sky-500",    bg: "bg-sky-50 text-sky-600" },
  medium: { label: "Medium", color: "text-amber-500",  bg: "bg-amber-50 text-amber-600" },
  high:   { label: "High",   color: "text-red-500",    bg: "bg-red-50 text-red-600" },
} as const;

export function TaskItem({ task, index, onDragStart, onDragOver, onDrop, isDragging }: TaskItemProps) {
  const queryClient = useQueryClient();
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);

  const toggleMutation = useToggleTask({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }),
    },
  });

  const deleteMutation = useDeleteTask({
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }),
    },
  });

  const parsedDate = task.dueDate ? parseISO(task.dueDate) : null;
  const isOverdue  = parsedDate && !task.completed && isPast(startOfDay(parsedDate)) && !isToday(parsedDate);
  const isDueToday = parsedDate && !task.completed && isToday(parsedDate);

  const priority = (task.priority ?? "none") as keyof typeof PRIORITY_CONFIG;
  const pConfig  = PRIORITY_CONFIG[priority];

  return (
    <>
      <div
        draggable
        onDragStart={(e) => onDragStart(e, index)}
        onDragOver={onDragOver}
        onDrop={(e) => onDrop(e, index)}
        className={cn(
          "group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex items-center p-4 overflow-hidden",
          isDragging && "opacity-50 scale-[0.99]",
          isOverdue && !task.completed && "border-l-[3px] border-l-[#EF4444]",
          isDueToday && !isOverdue && "border-l-[3px] border-l-[#F59E0B]",
          priority === "high" && !isOverdue && !isDueToday && !task.completed && "border-l-[3px] border-l-red-400",
          task.completed && "opacity-55"
        )}
      >
        {/* Drag handle */}
        <div
          className="cursor-grab active:cursor-grabbing text-slate-300 hover:text-slate-500 px-1.5 py-4 -ml-1 mr-1 flex-shrink-0 transition-colors"
          title="Drag to reorder"
        >
          <GripVertical size={16} />
        </div>

        {/* Checkbox */}
        <button
          onClick={() => toggleMutation.mutate({ id: task.id })}
          className="mr-4 flex-shrink-0 transition-colors text-slate-300 hover:text-[#22C55E]"
          disabled={toggleMutation.isPending}
        >
          {task.completed ? (
            <CheckCircle2 size={22} className="text-[#22C55E]" strokeWidth={2} />
          ) : (
            <Circle size={22} strokeWidth={2} />
          )}
        </button>

        {/* Content */}
        <div className="flex-1 min-w-0 mr-4">
          <div className="flex items-center gap-2 flex-wrap">
            <h3
              className={cn(
                "text-[15px] font-semibold leading-snug",
                task.completed ? "line-through text-slate-400" : "text-slate-800",
                isOverdue && !task.completed && "text-[#EF4444]"
              )}
            >
              {task.title}
            </h3>
            {pConfig.label && !task.completed && (
              <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold", pConfig.bg)}>
                <Flag size={10} />
                {pConfig.label}
              </span>
            )}
          </div>
          {task.description && (
            <p className={cn(
              "text-sm text-slate-500 truncate mt-0.5",
              task.completed && "line-through"
            )}>
              {task.description}
            </p>
          )}
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2 ml-auto flex-shrink-0">
          {isOverdue && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-bold bg-red-100 text-[#EF4444] uppercase tracking-wider">
              <AlertCircle size={12} />
              Overdue
            </span>
          )}

          {task.dueDate && (
            <div className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium",
              isOverdue  ? "text-[#EF4444] bg-red-50/50" :
              isDueToday ? "text-[#F59E0B] bg-amber-50/50" :
                           "text-slate-500 bg-slate-50"
            )}>
              <Calendar size={14} className={
                isOverdue  ? "text-[#EF4444]" :
                isDueToday ? "text-[#F59E0B]" :
                             "text-slate-400"
              } />
              {format(parseISO(task.dueDate), "MMM d, yyyy")}
            </div>
          )}

          <div className="flex items-center opacity-0 group-hover:opacity-100 transition-opacity ml-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-400 hover:text-[#2563EB] hover:bg-blue-50"
              onClick={() => setIsEditOpen(true)}
            >
              <Pencil size={15} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-slate-400 hover:text-[#EF4444] hover:bg-red-50"
              onClick={() => setIsDeleteOpen(true)}
            >
              <Trash2 size={15} />
            </Button>
          </div>
        </div>
      </div>

      <TaskForm task={task} open={isEditOpen} onOpenChange={setIsEditOpen} />

      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this task?</AlertDialogTitle>
            <AlertDialogDescription>
              "{task.title}" will be permanently deleted. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#EF4444] hover:bg-red-600 text-white"
              onClick={(e) => {
                e.preventDefault();
                deleteMutation.mutate({ id: task.id }, {
                  onSuccess: () => setIsDeleteOpen(false),
                });
              }}
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
