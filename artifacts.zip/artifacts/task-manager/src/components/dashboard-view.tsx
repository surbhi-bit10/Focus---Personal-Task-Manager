import { useMemo } from "react";
import {
  CheckCircle2, Clock, AlertCircle, TrendingUp, Plus,
  ArrowRight, CheckSquare, Flag, Zap,
} from "lucide-react";
import { format, isPast, isToday, parseISO, startOfDay, isThisWeek } from "date-fns";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Task } from "@workspace/api-client-react";
import type { NavId } from "@/pages/home";

interface Props {
  stats: { total: number; active: number; completed: number; overdue: number } | undefined;
  allTasks: Task[];
  onCreateTask: () => void;
  onNavigate: (id: NavId) => void;
}

const PRIORITY_COLOR: Record<string, string> = {
  high:   "bg-red-500",
  medium: "bg-amber-400",
  low:    "bg-sky-400",
  none:   "bg-slate-300",
};

export function DashboardView({ stats, allTasks, onCreateTask, onNavigate }: Props) {
  const total     = stats?.total     ?? 0;
  const completed = stats?.completed ?? 0;
  const active    = stats?.active    ?? 0;
  const overdue   = stats?.overdue   ?? 0;
  const pct       = total > 0 ? Math.round((completed / total) * 100) : 0;

  const recentTasks  = useMemo(() =>
    [...allTasks].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5),
    [allTasks]
  );

  const overdueTasks = useMemo(() =>
    allTasks.filter((t) => {
      if (t.completed || !t.dueDate) return false;
      const d = parseISO(t.dueDate);
      return isPast(startOfDay(d)) && !isToday(d);
    }),
    [allTasks]
  );

  const dueSoon = useMemo(() =>
    allTasks.filter((t) => {
      if (t.completed || !t.dueDate) return false;
      const d = parseISO(t.dueDate);
      return isThisWeek(d, { weekStartsOn: 1 }) && (!isPast(startOfDay(d)) || isToday(d));
    }),
    [allTasks]
  );

  const byPriority = useMemo(() => {
    const counts = { high: 0, medium: 0, low: 0, none: 0 };
    allTasks.filter((t) => !t.completed).forEach((t) => {
      const p = (t.priority ?? "none") as keyof typeof counts;
      counts[p]++;
    });
    return counts;
  }, [allTasks]);

  const circumference = 2 * Math.PI * 34;
  const dashOffset    = circumference - (pct / 100) * circumference;

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">

      {/* ── Welcome banner ────────────────────────────── */}
      <div className="bg-gradient-to-br from-[#1E3A8A] to-[#2563EB] rounded-2xl p-7 text-white relative overflow-hidden shadow-lg shadow-blue-500/20">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/5 rounded-full -translate-y-24 translate-x-16" />
        <div className="absolute right-20 bottom-0 w-40 h-40 bg-white/5 rounded-full translate-y-16" />
        <div className="relative z-10">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-blue-200 text-sm font-medium mb-1">Good {greeting()},</p>
              <h2 className="text-2xl font-bold">Here's your workspace overview</h2>
              <p className="text-blue-200 text-sm mt-2 max-w-md">
                You have <span className="text-white font-semibold">{active} active task{active !== 1 ? "s" : ""}</span>
                {overdue > 0 && <>, including <span className="text-red-300 font-semibold">{overdue} overdue</span></>}.
                {active === 0 && " All caught up — great work!"}
              </p>
            </div>
            <Button
              onClick={onCreateTask}
              className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm h-10 px-4 text-sm font-semibold flex-shrink-0 rounded-lg"
            >
              <Plus size={16} className="mr-1.5" />
              New Task
            </Button>
          </div>
        </div>
      </div>

      {/* ── Stats row ─────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: <CheckSquare size={20} />, iconBg: "bg-slate-100 text-slate-600", label: "Total",     value: total,     nav: "tasks" as NavId },
          { icon: <Clock size={20} />,       iconBg: "bg-blue-100 text-[#2563EB]",  label: "Active",    value: active,    nav: "tasks" as NavId, tint: "bg-blue-50/40" },
          { icon: <CheckCircle2 size={20} />,iconBg: "bg-emerald-100 text-[#22C55E]", label: "Done",   value: completed, nav: "completed" as NavId, tint: "bg-emerald-50/40" },
          { icon: <AlertCircle size={20} />, iconBg: "bg-red-100 text-[#EF4444]",   label: "Overdue",  value: overdue,   nav: "tasks" as NavId, tint: "bg-red-50/40" },
        ].map(({ icon, iconBg, label, value, nav, tint }) => (
          <button
            key={label}
            onClick={() => onNavigate(nav)}
            className={cn(
              "bg-white rounded-xl p-5 border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex items-center gap-4 relative overflow-hidden text-left group"
            )}
          >
            {tint && <div className={cn("absolute inset-0", tint)} />}
            <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 relative z-10", iconBg)}>{icon}</div>
            <div className="relative z-10">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wide">{label}</p>
              <p className="text-2xl font-bold text-slate-900 leading-none mt-0.5">{value}</p>
            </div>
            <ArrowRight size={14} className="ml-auto text-slate-300 group-hover:text-slate-500 transition-colors relative z-10" />
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* ── Progress ring ──────────────────────────── */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 flex flex-col items-center justify-center">
          <p className="text-sm font-semibold text-slate-700 mb-5 self-start">Completion Rate</p>
          <div className="relative w-24 h-24 mb-4">
            <svg viewBox="0 0 80 80" className="w-full h-full -rotate-90">
              <circle cx="40" cy="40" r="34" fill="none" stroke="#E2E8F0" strokeWidth="8" />
              <circle
                cx="40" cy="40" r="34"
                fill="none"
                stroke="#2563EB"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={dashOffset}
                className="transition-all duration-700"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-xl font-bold text-slate-900">{pct}%</span>
            </div>
          </div>
          <p className="text-sm text-slate-500 text-center">
            <span className="font-semibold text-slate-800">{completed}</span> of <span className="font-semibold text-slate-800">{total}</span> tasks complete
          </p>

          {/* Mini bar breakdown */}
          <div className="w-full mt-5 space-y-2">
            {total > 0 && (
              <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden flex">
                <div
                  className="bg-[#22C55E] h-full transition-all duration-700"
                  style={{ width: `${(completed / total) * 100}%` }}
                />
                <div
                  className="bg-[#2563EB] h-full transition-all duration-700"
                  style={{ width: `${(active / total) * 100}%` }}
                />
              </div>
            )}
            <div className="flex items-center gap-4 text-xs text-slate-500">
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#22C55E] inline-block" />Done</span>
              <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#2563EB] inline-block" />Active</span>
            </div>
          </div>
        </div>

        {/* ── Priority breakdown ─────────────────────── */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <p className="text-sm font-semibold text-slate-700 mb-5">Active by Priority</p>
          <div className="space-y-3">
            {(["high", "medium", "low", "none"] as const).map((p) => {
              const count = byPriority[p];
              const label = p === "none" ? "Unset" : p.charAt(0).toUpperCase() + p.slice(1);
              const max   = Math.max(...Object.values(byPriority), 1);
              return (
                <div key={p} className="flex items-center gap-3">
                  <div className={cn("w-2.5 h-2.5 rounded-full flex-shrink-0", PRIORITY_COLOR[p])} />
                  <span className="text-sm text-slate-600 w-16">{label}</span>
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={cn("h-full rounded-full transition-all duration-700", PRIORITY_COLOR[p])}
                      style={{ width: `${(count / max) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-semibold text-slate-800 w-5 text-right">{count}</span>
                </div>
              );
            })}
          </div>

          {active === 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-2 text-emerald-600 text-sm">
              <Zap size={14} className="flex-shrink-0" />
              <span className="font-medium">Inbox zero — all clear!</span>
            </div>
          )}
        </div>

        {/* ── Due this week ──────────────────────────── */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          <div className="flex items-center justify-between mb-5">
            <p className="text-sm font-semibold text-slate-700">Due This Week</p>
            <span className="text-xs bg-blue-50 text-[#2563EB] font-semibold px-2 py-1 rounded-md">{dueSoon.length}</span>
          </div>

          {dueSoon.length === 0 ? (
            <p className="text-sm text-slate-400 text-center py-8">Nothing due this week</p>
          ) : (
            <div className="space-y-2">
              {dueSoon.slice(0, 5).map((t) => (
                <div key={t.id} className="flex items-center gap-2.5 py-1.5">
                  <div className={cn("w-2 h-2 rounded-full flex-shrink-0", PRIORITY_COLOR[t.priority ?? "none"])} />
                  <p className="text-sm text-slate-700 truncate flex-1">{t.title}</p>
                  {t.dueDate && (
                    <span className={cn(
                      "text-xs font-medium flex-shrink-0 px-1.5 py-0.5 rounded",
                      isToday(parseISO(t.dueDate)) ? "text-amber-600 bg-amber-50" : "text-slate-500 bg-slate-50"
                    )}>
                      {isToday(parseISO(t.dueDate)) ? "Today" : format(parseISO(t.dueDate), "EEE d")}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Recent tasks ──────────────────────────────── */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <p className="text-sm font-semibold text-slate-700">Recently Added</p>
          <button
            onClick={() => onNavigate("tasks")}
            className="flex items-center gap-1 text-xs text-[#2563EB] hover:text-blue-700 font-medium transition-colors"
          >
            View all <ArrowRight size={13} />
          </button>
        </div>

        {recentTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <p className="text-sm text-slate-400 mb-3">No tasks yet</p>
            <Button onClick={onCreateTask} size="sm" className="bg-[#2563EB] hover:bg-blue-700 text-white h-8 px-3 text-xs">
              <Plus size={13} className="mr-1" />
              Create first task
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-slate-50">
            {recentTasks.map((t) => {
              const p         = (t.priority ?? "none") as keyof typeof PRIORITY_COLOR;
              const parsedDate = t.dueDate ? parseISO(t.dueDate) : null;
              const isOv      = parsedDate && !t.completed && isPast(startOfDay(parsedDate)) && !isToday(parsedDate);
              return (
                <div key={t.id} className="flex items-center gap-4 px-6 py-3.5 hover:bg-slate-50/60 transition-colors">
                  <div className={cn(
                    "w-1 h-8 rounded-full flex-shrink-0",
                    isOv ? "bg-[#EF4444]" : PRIORITY_COLOR[p]
                  )} />
                  <div className="flex-1 min-w-0">
                    <p className={cn(
                      "text-sm font-medium truncate",
                      t.completed ? "line-through text-slate-400" : "text-slate-800"
                    )}>
                      {t.title}
                    </p>
                    {t.description && (
                      <p className="text-xs text-slate-400 truncate mt-0.5">{t.description}</p>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {t.completed ? (
                      <span className="text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md font-medium">Done</span>
                    ) : isOv ? (
                      <span className="text-xs text-red-500 bg-red-50 px-2 py-0.5 rounded-md font-semibold uppercase tracking-wide">Overdue</span>
                    ) : t.dueDate ? (
                      <span className={cn(
                        "text-xs px-2 py-0.5 rounded-md font-medium",
                        isToday(parseISO(t.dueDate)) ? "text-amber-600 bg-amber-50" : "text-slate-500 bg-slate-50"
                      )}>
                        {isToday(parseISO(t.dueDate)) ? "Due today" : format(parseISO(t.dueDate), "MMM d")}
                      </span>
                    ) : null}
                    <Flag size={12} className={cn(PRIORITY_COLOR[p].replace("bg-", "text-").replace("-500", "-400").replace("-400", "-400").replace("-300", "-300"))} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── Overdue alert ─────────────────────────────── */}
      {overdueTasks.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-5 flex items-start gap-4">
          <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center flex-shrink-0">
            <AlertCircle size={20} className="text-[#EF4444]" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-800">
              {overdueTasks.length} overdue task{overdueTasks.length !== 1 ? "s" : ""} need your attention
            </p>
            <p className="text-xs text-red-600 mt-1">
              {overdueTasks.slice(0, 2).map((t) => t.title).join(", ")}
              {overdueTasks.length > 2 && ` and ${overdueTasks.length - 2} more…`}
            </p>
          </div>
          <button
            onClick={() => onNavigate("tasks")}
            className="text-xs text-red-600 font-semibold hover:text-red-800 flex items-center gap-1 flex-shrink-0 transition-colors"
          >
            Review <ArrowRight size={13} />
          </button>
        </div>
      )}
    </div>
  );
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}
