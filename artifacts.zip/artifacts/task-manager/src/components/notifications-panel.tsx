import { useMemo } from "react";
import { X, AlertCircle, Clock, CheckCircle2, Bell } from "lucide-react";
import { format, isPast, isToday, parseISO, startOfDay, isYesterday, differenceInDays } from "date-fns";
import { cn } from "@/lib/utils";
import type { Task } from "@workspace/api-client-react";

interface Props {
  open: boolean;
  onClose: () => void;
  allTasks: Task[];
}

export function NotificationsPanel({ open, onClose, allTasks }: Props) {
  const overdueTasks = useMemo(() =>
    allTasks.filter((t) => {
      if (t.completed || !t.dueDate) return false;
      const d = parseISO(t.dueDate);
      return isPast(startOfDay(d)) && !isToday(d);
    }).sort((a, b) => {
      // most overdue first
      return new Date(a.dueDate!).getTime() - new Date(b.dueDate!).getTime();
    }),
    [allTasks]
  );

  const todayTasks = useMemo(() =>
    allTasks.filter((t) => !t.completed && t.dueDate && isToday(parseISO(t.dueDate))),
    [allTasks]
  );

  const recentlyCompleted = useMemo(() =>
    allTasks
      .filter((t) => t.completed)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, 3),
    [allTasks]
  );

  const total = overdueTasks.length + todayTasks.length;

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/20 backdrop-blur-[2px]"
          onClick={onClose}
        />
      )}

      {/* Panel */}
      <div
        className={cn(
          "fixed top-0 right-0 h-full w-[360px] bg-white border-l border-slate-200 shadow-2xl z-50 flex flex-col transition-transform duration-300",
          open ? "translate-x-0" : "translate-x-full"
        )}
        style={{ fontFamily: "'Inter', sans-serif" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <Bell size={18} className="text-slate-700" />
            <h2 className="text-base font-semibold text-slate-900">Notifications</h2>
            {total > 0 && (
              <span className="w-5 h-5 bg-[#EF4444] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {total > 9 ? "9+" : total}
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">

          {/* Overdue section */}
          {overdueTasks.length > 0 && (
            <Section
              icon={<AlertCircle size={15} />}
              iconColor="text-[#EF4444]"
              bgColor="bg-red-50"
              title="Overdue"
              count={overdueTasks.length}
              countColor="bg-red-100 text-red-600"
            >
              {overdueTasks.map((t) => {
                const days = differenceInDays(new Date(), parseISO(t.dueDate!));
                return (
                  <NotifItem key={t.id} task={t}>
                    <span className="text-[11px] text-red-500 font-semibold">
                      {days === 0 ? "Due yesterday" : `${days} day${days !== 1 ? "s" : ""} overdue`}
                    </span>
                  </NotifItem>
                );
              })}
            </Section>
          )}

          {/* Due today section */}
          {todayTasks.length > 0 && (
            <Section
              icon={<Clock size={15} />}
              iconColor="text-amber-500"
              bgColor="bg-amber-50"
              title="Due Today"
              count={todayTasks.length}
              countColor="bg-amber-100 text-amber-600"
            >
              {todayTasks.map((t) => (
                <NotifItem key={t.id} task={t}>
                  <span className="text-[11px] text-amber-600 font-medium">Due today</span>
                </NotifItem>
              ))}
            </Section>
          )}

          {/* Recently completed */}
          {recentlyCompleted.length > 0 && (
            <Section
              icon={<CheckCircle2 size={15} />}
              iconColor="text-[#22C55E]"
              bgColor="bg-emerald-50"
              title="Recently Done"
              count={recentlyCompleted.length}
              countColor="bg-emerald-100 text-emerald-600"
            >
              {recentlyCompleted.map((t) => (
                <NotifItem key={t.id} task={t} completed>
                  <span className="text-[11px] text-slate-400">
                    Completed {isYesterday(new Date(t.updatedAt)) ? "yesterday" : format(new Date(t.updatedAt), "MMM d")}
                  </span>
                </NotifItem>
              ))}
            </Section>
          )}

          {/* Empty */}
          {total === 0 && recentlyCompleted.length === 0 && (
            <div className="flex flex-col items-center justify-center py-20 text-center px-8">
              <div className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                <Bell size={22} className="text-slate-400" />
              </div>
              <p className="text-sm font-semibold text-slate-700">All caught up!</p>
              <p className="text-xs text-slate-400 mt-1.5">No overdue or due-today tasks.</p>
            </div>
          )}
          {total === 0 && recentlyCompleted.length === 0 && allTasks.length > 0 && null}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50">
          <p className="text-xs text-slate-400 text-center">
            {allTasks.length} total tasks · {allTasks.filter((t) => !t.completed).length} active
          </p>
        </div>
      </div>
    </>
  );
}

function Section({
  icon, iconColor, bgColor, title, count, countColor, children,
}: {
  icon: React.ReactNode; iconColor: string; bgColor: string;
  title: string; count: number; countColor: string;
  children: React.ReactNode;
}) {
  return (
    <div className="border-b border-slate-100 last:border-0">
      <div className={cn("flex items-center gap-2 px-6 py-3", bgColor)}>
        <span className={cn("flex-shrink-0", iconColor)}>{icon}</span>
        <span className="text-xs font-semibold text-slate-700 flex-1">{title}</span>
        <span className={cn("text-[11px] font-bold px-1.5 py-0.5 rounded-full", countColor)}>{count}</span>
      </div>
      <div className="px-4 py-2 space-y-0.5">
        {children}
      </div>
    </div>
  );
}

function NotifItem({ task, completed, children }: {
  task: Task; completed?: boolean; children: React.ReactNode;
}) {
  return (
    <div className={cn(
      "flex items-start gap-3 px-2 py-2.5 rounded-lg transition-colors hover:bg-slate-50",
    )}>
      {completed
        ? <CheckCircle2 size={16} className="text-[#22C55E] flex-shrink-0 mt-0.5" />
        : <AlertCircle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
      }
      <div className="flex-1 min-w-0">
        <p className={cn(
          "text-sm font-medium leading-snug",
          completed ? "line-through text-slate-400" : "text-slate-800"
        )}>
          {task.title}
        </p>
        {children}
      </div>
    </div>
  );
}
