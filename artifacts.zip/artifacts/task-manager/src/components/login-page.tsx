import { useState } from "react";
import { Eye, EyeOff, Loader2, CheckCircle2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import type { User } from "@/pages/home";

interface LoginPageProps {
  onLogin: (user: User) => void;
}

const DEMO_ACCOUNTS: { name: string; email: string; initials: string; role: string }[] = [
  { name: "Alex Johnson", email: "alex@acme.com", initials: "AJ", role: "Product Manager" },
  { name: "Sam Rivera",   email: "sam@acme.com",  initials: "SR", role: "Engineer" },
  { name: "Taylor Kim",   email: "taylor@acme.com", initials: "TK", role: "Designer" },
];

const FEATURES = [
  "Drag-and-drop task reordering",
  "Smart overdue detection",
  "Priority-based filtering",
  "Calendar view",
  "CSV export",
];

export function LoginPage({ onLogin }: LoginPageProps) {
  const [email, setEmail]         = useState("");
  const [password, setPassword]   = useState("");
  const [showPass, setShowPass]   = useState(false);
  const [loading, setLoading]     = useState(false);
  const [error, setError]         = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!email.trim()) { setError("Email is required."); return; }
    if (!password.trim()) { setError("Password is required."); return; }

    setLoading(true);
    await new Promise((r) => setTimeout(r, 900));
    setLoading(false);

    const name     = email.split("@")[0]!.replace(/[._-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    const initials = name.split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();
    onLogin({ name, email, initials });
  };

  const loginAs = (account: typeof DEMO_ACCOUNTS[number]) => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin({ name: account.name, email: account.email, initials: account.initials });
    }, 600);
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── Left panel ───────────────────────────────── */}
      <div className="hidden lg:flex w-[520px] flex-shrink-0 bg-[#0F172A] flex-col justify-between p-12 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-[#2563EB]/10 rounded-full -translate-y-32 translate-x-32" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#2563EB]/5 rounded-full translate-y-40 -translate-x-20" />

        {/* Logo */}
        <div className="flex items-center gap-3 relative z-10">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB] flex items-center justify-center text-white font-bold text-2xl shadow-xl shadow-blue-500/30">
            F
          </div>
          <span className="text-white text-2xl font-bold tracking-tight">Focus</span>
        </div>

        {/* Headline */}
        <div className="relative z-10">
          <h2 className="text-4xl font-bold text-white leading-snug mb-4">
            Get more done,<br />
            <span className="text-[#2563EB]">stay organized.</span>
          </h2>
          <p className="text-slate-400 text-base mb-8 leading-relaxed">
            Focus helps teams and individuals manage work with clarity — from quick tasks to complex projects.
          </p>

          <ul className="space-y-3">
            {FEATURES.map((f) => (
              <li key={f} className="flex items-center gap-3 text-slate-300 text-sm">
                <CheckCircle2 size={16} className="text-[#2563EB] flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>
        </div>

        <p className="text-slate-600 text-xs relative z-10">© {new Date().getFullYear()} Focus. All rights reserved.</p>
      </div>

      {/* ── Right panel ─────────────────────────────── */}
      <div className="flex-1 flex items-center justify-center px-6 bg-[#F8FAFC]">
        <div className="w-full max-w-[400px]">

          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-2.5 mb-8">
            <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white font-bold text-lg">
              F
            </div>
            <span className="text-slate-900 text-xl font-bold tracking-tight">Focus</span>
          </div>

          <div className="mb-8">
            <h1 className="text-2xl font-bold text-slate-900">Sign in to your workspace</h1>
            <p className="text-slate-500 text-sm mt-1.5">Enter your credentials or use a demo account below.</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Email address</label>
              <Input
                type="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-11 border-slate-300 focus-visible:ring-[#2563EB] text-sm"
                autoComplete="email"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
              <div className="relative">
                <Input
                  type={showPass ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 border-slate-300 focus-visible:ring-[#2563EB] text-sm pr-11"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                >
                  {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-sm text-red-500 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full h-11 bg-[#2563EB] hover:bg-blue-700 text-white font-semibold text-sm shadow-md shadow-blue-500/25 rounded-lg"
            >
              {loading ? <Loader2 size={18} className="animate-spin mr-2" /> : null}
              {loading ? "Signing in…" : "Sign in"}
            </Button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-slate-200" />
            <span className="text-slate-400 text-xs font-medium">or try a demo account</span>
            <div className="flex-1 h-px bg-slate-200" />
          </div>

          {/* Demo accounts */}
          <div className="space-y-2">
            {DEMO_ACCOUNTS.map((acc) => (
              <button
                key={acc.email}
                onClick={() => loginAs(acc)}
                disabled={loading}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-slate-200 bg-white hover:border-[#2563EB] hover:bg-blue-50/30 transition-all text-left group",
                  loading && "opacity-50 pointer-events-none"
                )}
              >
                <div className="w-9 h-9 rounded-full bg-[#2563EB] text-white text-sm font-bold flex items-center justify-center flex-shrink-0 shadow-sm">
                  {acc.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800 group-hover:text-[#2563EB] transition-colors">{acc.name}</p>
                  <p className="text-xs text-slate-500">{acc.role} · {acc.email}</p>
                </div>
                <Zap size={14} className="text-slate-300 group-hover:text-[#2563EB] transition-colors flex-shrink-0" />
              </button>
            ))}
          </div>

          <p className="text-center text-xs text-slate-400 mt-6">
            No real authentication — all data is public and shared.
          </p>
        </div>
      </div>
    </div>
  );
}
