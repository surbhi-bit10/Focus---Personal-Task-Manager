import { useState, useEffect, useCallback } from "react";
import {
  Plus, Search, CheckCircle2, LayoutDashboard, CheckSquare,
  Calendar, Settings, AlertCircle, Clock, Loader2,
  Inbox, ListTodo, Bell, Trash2, CheckCheck,
  LogOut, User, X, ChevronRight, Zap,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

import { useDebounce } from "@/hooks/use-debounce";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { TaskItem } from "@/components/task-item";
import { TaskForm } from "@/components/task-form";
import { DashboardView } from "@/components/dashboard-view";
import { CalendarView } from "@/components/calendar-view";
import { SearchPalette } from "@/components/search-palette";
import { NotificationsPanel } from "@/components/notifications-panel";
import { SettingsPanel } from "@/components/settings-panel";
import { LoginPage } from "@/components/login-page";
import { cn } from "@/lib/utils";

import {
  useListTasks,
  useGetTaskStats,
  useReorderTasks,
  useBulkCompleteTasks,
  useBulkDeleteCompleted,
} from "@workspace/api-client-react";
import type { Task, ListTasksStatus } from "@workspace/api-client-react";

type FilterTab = "All" | "Active" | "Completed";
export type NavId = "dashboard" | "tasks" | "completed" | "calendar";

const NAV_ITEMS: { icon: React.ElementType; label: string; id: NavId }[] = [
  { icon: LayoutDashboard, label: "Dashboard",  id: "dashboard" },
  { icon: CheckSquare,     label: "My Tasks",   id: "tasks" },
  { icon: CheckCircle2,    label: "Completed",  id: "completed" },
  { icon: Calendar,        label: "Calendar",   id: "calendar" },
];

export interface User {
  name: string;
  email: string;
  initials: string;
}

export default function Home() {
  const queryClient = useQueryClient();

  // ── Auth state ───────────────────────────────────────────────────────────
  const [isLoggedIn, setIsLoggedIn]   = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // ── Navigation ───────────────────────────────────────────────────────────
  const [activeNav, setActiveNav]     = useState<NavId>("tasks");

  // ── Tasks state ──────────────────────────────────────────────────────────
  const [search, setSearch]           = useState("");
  const debouncedSearch               = useDebounce(search, 300);
  const [status, setStatus]           = useState<ListTasksStatus>("all");
  const [activeFilter, setFilter]     = useState<FilterTab>("All");
  const [isCreateOpen, setCreate]     = useState(false);
  const [localTasks, setLocalTasks]   = useState<Task[]>([]);
  const [draggingIdx, setDragging]    = useState<number | null>(null);
  const [bulkAction, setBulkAction]   = useState<"complete" | "delete" | null>(null);

  // ── Panels ───────────────────────────────────────────────────────────────
  const [searchOpen, setSearchOpen]         = useState(false);
  const [notificationsOpen, setNotifOpen]   = useState(false);
  const [settingsOpen, setSettingsOpen]     = useState(false);

  // ── Data ─────────────────────────────────────────────────────────────────
  const { data: stats } = useGetTaskStats({
    query: { queryKey: ["/api/tasks", "stats"] },
  });

  const { data: tasks, isLoading } = useListTasks(
    { status, search: debouncedSearch || undefined },
    { query: { queryKey: ["/api/tasks", status, debouncedSearch] } }
  );

  const { data: allTasks } = useListTasks(
    { status: "all" },
    { query: { queryKey: ["/api/tasks", "all", ""] } }
  );

  const reorderMutation = useReorderTasks({
    mutation: { onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/tasks"] }) },
  });

  const bulkCompleteMutation = useBulkCompleteTasks({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
        setBulkAction(null);
      },
    },
  });

  const bulkDeleteMutation = useBulkDeleteCompleted({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
        setBulkAction(null);
      },
    },
  });

  useEffect(() => {
    if (tasks) setLocalTasks(tasks);
  }, [tasks]);

  // ── Keyboard shortcut: Cmd+K → search ────────────────────────────────────
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === "Escape") {
        setSearchOpen(false);
        setNotifOpen(false);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // ── Handlers ─────────────────────────────────────────────────────────────
  const handleLogin = useCallback((user: User) => {
    setCurrentUser(user);
    setIsLoggedIn(true);
    setActiveNav("dashboard");
  }, []);

  const handleLogout = useCallback(() => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setActiveNav("tasks");
    setNotifOpen(false);
    setSettingsOpen(false);
  }, []);

  const handleUpdateUser = useCallback((user: User) => {
    setCurrentUser(user);
  }, []);

  const handleNavClick = (id: NavId) => {
    setActiveNav(id);
    if (id === "completed") {
      setFilter("Completed");
      setStatus("completed");
    } else if (id === "tasks") {
      setFilter("All");
      setStatus("all");
    }
  };

  const handleFilterChange = (f: FilterTab) => {
    setFilter(f);
    const map: Record<FilterTab, ListTasksStatus> = { All: "all", Active: "active", Completed: "completed" };
    setStatus(map[f]);
  };

  const handleExport = () => {
    const params = new URLSearchParams();
    if (status !== "all") params.set("status", status);
    window.open(`/api/tasks/export?${params.toString()}`, "_blank");
  };

  const handleDragStart = (e: React.DragEvent, i: number) => {
    setDragging(i);
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", i.toString());
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, target: number) => {
    e.preventDefault();
    const src = parseInt(e.dataTransfer.getData("text/plain"), 10);
    setDragging(null);
    if (src === target || isNaN(src)) return;
    const next = [...localTasks];
    const [moved] = next.splice(src, 1);
    next.splice(target, 0, moved);
    setLocalTasks(next);
    reorderMutation.mutate({
      data: { order: next.map((t, idx) => ({ id: t.id, sortOrder: idx })) },
    });
  };

  const activeCount    = stats?.active    ?? 0;
  const completedCount = stats?.completed ?? 0;
  const overdueCount   = stats?.overdue   ?? 0;
  const hasActive      = activeCount > 0;
  const hasCompleted   = completedCount > 0;

  const navLabel: Record<NavId, string> = {
    dashboard: "Dashboard",
    tasks:     "My Tasks",
    completed: "Completed",
    calendar:  "Calendar",
  };
  const navSub: Record<NavId, string> = {
    dashboard: "Overview of your workspace",
    tasks:     "Organize and prioritize your work",
    completed: "Tasks you've finished",
    calendar:  "View tasks by date",
  };

  // ── Login gate ───────────────────────────────────────────────────────────
  if (!isLoggedIn) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#F8FAFC]" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── Sidebar ─────────────────────────────────────── */}
      <aside className="w-[240px] flex-shrink-0 bg-[#0F172A] text-slate-300 flex flex-col h-full shadow-xl z-20">
        {/* Logo */}
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="w-8 h-8 rounded-lg bg-[#2563EB] flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-blue-500/20">
            F
          </div>
          <span className="text-white text-xl font-bold tracking-tight">Focus</span>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-6 px-4 space-y-1">
          {NAV_ITEMS.map(({ icon: Icon, label, id }) => {
            const isActive = activeNav === id;
            return (
              <button
                key={id}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 relative",
                  isActive
                    ? "text-white bg-slate-800/80"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/50"
                )}
                onClick={() => handleNavClick(id)}
              >
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#2563EB] rounded-r-full" />
                )}
                <Icon size={18} className={cn("flex-shrink-0", isActive ? "text-[#2563EB]" : "")} />
                <span>{label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="mt-auto p-4 border-t border-slate-800">
          <button
            onClick={() => setSettingsOpen(true)}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors mb-4 text-sm font-medium"
          >
            <Settings size={18} />
            Settings
          </button>

          {/* User dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-slate-800/50 rounded-lg cursor-pointer transition-colors group">
                <Avatar className="h-8 w-8 border-2 border-slate-700 flex-shrink-0 group-hover:border-[#2563EB] transition-colors">
                  <AvatarFallback className="bg-[#2563EB] text-white text-sm font-bold">
                    {currentUser?.initials ?? "U"}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col min-w-0 text-left flex-1">
                  <span className="text-sm font-semibold text-white truncate">{currentUser?.name ?? "My Account"}</span>
                  <span className="text-xs text-slate-500 truncate">{currentUser?.email ?? "Personal workspace"}</span>
                </div>
                <ChevronRight size={14} className="text-slate-600 flex-shrink-0" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="w-[200px] mb-1">
              <DropdownMenuLabel>
                <div className="font-normal">
                  <p className="font-semibold text-slate-900">{currentUser?.name}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{currentUser?.email}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2 cursor-pointer">
                <User size={14} />
                View profile
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2 cursor-pointer">
                <Settings size={14} />
                Preferences
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="gap-2 cursor-pointer text-red-600 focus:text-red-600 focus:bg-red-50"
                onClick={handleLogout}
              >
                <LogOut size={14} />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* ── Main ────────────────────────────────────────── */}
      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">

        {/* Header */}
        <header className="h-[72px] bg-white border-b border-slate-200 px-8 flex items-center justify-between flex-shrink-0 shadow-sm">
          <div>
            <h1 className="text-xl font-bold text-slate-900">{navLabel[activeNav]}</h1>
            <p className="text-xs font-medium text-slate-500 mt-0.5">{navSub[activeNav]}</p>
          </div>

          <div className="flex items-center gap-5">
            {/* Search input — opens palette on focus/type */}
            <div className="relative w-64 hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
              <Input
                placeholder="Search tasks..."
                onFocus={() => setSearchOpen(true)}
                onClick={() => setSearchOpen(true)}
                readOnly
                className="pl-9 bg-slate-50 border-slate-200 focus-visible:ring-[#2563EB] h-10 rounded-lg cursor-pointer"
              />
            </div>

            {/* Notifications */}
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setNotifOpen(true)}
              className="relative text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-full h-10 w-10"
            >
              <Bell size={20} />
              {overdueCount > 0 && (
                <span className="absolute top-2 right-2.5 w-2 h-2 bg-[#EF4444] rounded-full ring-2 ring-white" />
              )}
            </Button>

            {/* New task */}
            <Button
              className="bg-[#2563EB] hover:bg-blue-700 text-white rounded-lg h-10 px-4 shadow-md shadow-blue-500/20 font-medium"
              onClick={() => setCreate(true)}
            >
              <Plus size={18} className="mr-2" />
              New Task
            </Button>
          </div>
        </header>

        {/* ── Body ────────────────────────────────────── */}
        <div className="flex-1 overflow-auto">
          {activeNav === "dashboard" && (
            <DashboardView
              stats={stats}
              allTasks={allTasks ?? []}
              onCreateTask={() => setCreate(true)}
              onNavigate={handleNavClick}
            />
          )}

          {activeNav === "calendar" && (
            <CalendarView
              allTasks={allTasks ?? []}
              onCreateTask={() => setCreate(true)}
            />
          )}

          {(activeNav === "tasks" || activeNav === "completed") && (
            <div className="p-8">
              <div className="max-w-5xl mx-auto space-y-8">

                {/* Stats strip */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard
                    icon={<CheckSquare size={24} />}
                    iconBg="bg-slate-100 text-slate-600"
                    label="Total Tasks"
                    value={stats?.total ?? 0}
                    onClick={() => handleNavClick("tasks")}
                  />
                  <StatCard
                    icon={<Clock size={24} />}
                    iconBg="bg-blue-100 text-[#2563EB]"
                    tint="bg-blue-50/50"
                    label="Active Tasks"
                    value={activeCount}
                    onClick={() => { handleNavClick("tasks"); handleFilterChange("Active"); }}
                  />
                  <StatCard
                    icon={<CheckCircle2 size={24} />}
                    iconBg="bg-emerald-100 text-[#22C55E]"
                    tint="bg-emerald-50/50"
                    label="Completed"
                    value={completedCount}
                    onClick={() => handleNavClick("completed")}
                  />
                  <StatCard
                    icon={<AlertCircle size={24} />}
                    iconBg="bg-red-100 text-[#EF4444]"
                    tint="bg-red-50/50"
                    label="Overdue"
                    value={overdueCount}
                  />
                </div>

                {/* Task list */}
                <div>
                  <div className="flex items-center justify-between mb-5 gap-3 flex-wrap">
                    <h2 className="text-lg font-bold text-slate-900">
                      {activeNav === "completed" ? "Completed Tasks" : "Current Tasks"}
                    </h2>

                    <div className="flex items-center gap-2 flex-wrap">
                      {hasActive && activeFilter !== "Completed" && activeNav !== "completed" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-3 text-xs font-medium text-emerald-600 border-emerald-200 hover:bg-emerald-50 gap-1.5"
                          onClick={() => setBulkAction("complete")}
                        >
                          <CheckCheck size={13} />
                          Complete all
                        </Button>
                      )}
                      {hasCompleted && activeFilter !== "Active" && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 px-3 text-xs font-medium text-red-500 border-red-200 hover:bg-red-50 gap-1.5"
                          onClick={() => setBulkAction("delete")}
                        >
                          <Trash2 size={13} />
                          Delete completed
                        </Button>
                      )}

                      {activeNav !== "completed" && (
                        <div className="flex bg-slate-200/60 p-1 rounded-lg">
                          {(["All", "Active", "Completed"] as const).map((tab) => (
                            <button
                              key={tab}
                              onClick={() => handleFilterChange(tab)}
                              className={cn(
                                "px-4 py-1.5 text-sm font-medium rounded-md transition-all",
                                activeFilter === tab
                                  ? "bg-white text-[#2563EB] shadow-sm"
                                  : "text-slate-500 hover:text-slate-700"
                              )}
                            >
                              {tab}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {isLoading ? (
                    <div className="flex flex-col items-center justify-center py-20 text-slate-400">
                      <Loader2 className="h-8 w-8 animate-spin mb-4 text-[#2563EB]/40" />
                      <p className="text-sm">Loading your tasks…</p>
                    </div>
                  ) : localTasks.length > 0 ? (
                    <div className="space-y-3 pb-10">
                      {localTasks.map((task, index) => (
                        <TaskItem
                          key={task.id}
                          task={task}
                          index={index}
                          onDragStart={handleDragStart}
                          onDragOver={handleDragOver}
                          onDrop={handleDrop}
                          isDragging={draggingIdx === index}
                        />
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      status={status}
                      search={search}
                      onCreateTask={() => setCreate(true)}
                    />
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* ── Dialogs & panels ─────────────────────────────── */}
      <TaskForm open={isCreateOpen} onOpenChange={setCreate} />

      <SearchPalette
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        allTasks={allTasks ?? []}
        onNavigateTasks={() => { setSearchOpen(false); handleNavClick("tasks"); }}
      />

      <NotificationsPanel
        open={notificationsOpen}
        onClose={() => setNotifOpen(false)}
        allTasks={allTasks ?? []}
      />

      <SettingsPanel
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        currentUser={currentUser}
        onUpdateUser={handleUpdateUser}
        onExport={handleExport}
      />

      <AlertDialog open={bulkAction === "complete"} onOpenChange={(o) => !o && setBulkAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Mark all active tasks as complete?</AlertDialogTitle>
            <AlertDialogDescription>
              This will complete {activeCount} active task{activeCount !== 1 ? "s" : ""}. You can undo individual tasks afterwards.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#22C55E] hover:bg-emerald-600 text-white"
              onClick={(e) => { e.preventDefault(); bulkCompleteMutation.mutate(undefined as unknown as void); }}
            >
              {bulkCompleteMutation.isPending ? "Completing…" : `Complete ${activeCount}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkAction === "delete"} onOpenChange={(o) => !o && setBulkAction(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete all completed tasks?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {completedCount} completed task{completedCount !== 1 ? "s" : ""}. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#EF4444] hover:bg-red-600 text-white"
              onClick={(e) => { e.preventDefault(); bulkDeleteMutation.mutate(undefined as unknown as void); }}
            >
              {bulkDeleteMutation.isPending ? "Deleting…" : `Delete ${completedCount}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/* ── Stat card ─────────────────────────────────────────── */
function StatCard({
  icon, iconBg, tint = "", label, value, onClick,
}: {
  icon: React.ReactNode; iconBg: string; tint?: string;
  label: string; value: number; onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex items-center gap-4 relative overflow-hidden text-left w-full",
        onClick && "hover:shadow-md hover:border-slate-300 transition-all cursor-pointer"
      )}
    >
      {tint && <div className={cn("absolute inset-0", tint)} />}
      <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 relative z-10", iconBg)}>
        {icon}
      </div>
      <div className="relative z-10">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        <p className="text-2xl font-bold text-slate-900">{value}</p>
      </div>
    </button>
  );
}

/* ── Empty state ───────────────────────────────────────── */
function EmptyState({ status, search, onCreateTask }: {
  status: ListTasksStatus; search: string; onCreateTask: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-white/50">
      <div className="h-14 w-14 bg-blue-50 text-[#2563EB] rounded-full flex items-center justify-center mb-4">
        {status === "completed" ? <CheckCircle2 className="h-7 w-7" /> :
         status === "active"    ? <ListTodo className="h-7 w-7" /> :
                                  <Inbox className="h-7 w-7" />}
      </div>
      <h3 className="text-base font-semibold text-slate-800">No tasks found</h3>
      <p className="text-slate-500 text-sm mt-1 max-w-xs">
        {search
          ? "No tasks match your search."
          : status === "completed" ? "You haven't completed any tasks yet."
          : status === "active"    ? "No active tasks right now."
          : "Your task list is empty. Create your first task."}
      </p>
      {!search && status !== "completed" && (
        <Button
          className="mt-5 bg-[#2563EB] hover:bg-blue-700 text-white rounded-lg h-9 px-4 text-sm font-medium shadow-sm"
          onClick={onCreateTask}
        >
          <Plus className="h-4 w-4 mr-2" />
          Add your first task
        </Button>
      )}
    </div>
  );
}
